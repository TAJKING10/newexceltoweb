﻿# Payslip Generator - OVHcloud Deployment Package

This package contains everything needed to deploy the Payslip Generator application on OVHcloud.

## Contents

- **config/**: Configuration files (Docker Compose, environment templates, deployment script)
- **scripts/**: Setup scripts for different platforms
- **docs/**: Complete deployment documentation
- **app/**: Application source code and database migrations

## Quick Start

### Linux/macOS
1. Extract this package to your server
2. Navigate to the config directory: `cd config`
3. Run the setup script: `../scripts/quick-setup.sh`
4. Edit .env.production with your configuration
5. Run: `./ovhcloud-deploy.sh`

### Windows
1. Extract this package
2. Navigate to the config directory
3. Run: `..\scripts\setup-windows.bat`
4. Edit .env.production with your configuration
5. Run: `docker-compose up -d`

## Documentation

See the docs/ directory for complete guides:
- OVHCLOUD_DEPLOYMENT_GUIDE.md - Complete deployment instructions
- PRODUCTION_CHECKLIST.md - Pre-deployment checklist
- README.md - Application documentation

## Support

For issues and support, please refer to the documentation or contact your system administrator.

Generated on: 2025-09-22 02:38:06
Package version: 1.0.0
